from stellar_sdk import TransactionBuilder, Network, Keypair, Account, Server
import json
import requests
#import payments

server = Server(horizon_url="https://horizon-testnet.stellar.org")
base_fee = server.fetch_base_fee()
fbot_url = "https://friendbot.stellar.org"

def create_account():
    print("Creating testnet account")
    keypair = Keypair.random()
    response = requests.get(fbot_url, params={"addr": keypair.public_key})
    if response.status_code == 200:
        print("Account successfully created and funded by friendbot!")
    else:
        print("Possible issue with connection. Returned status code",
              response.status_code)
    
    print("Public Key: "+keypair.public_key)
    choice = input("View secret seed? (Y/N): ")
    if choice == 'Y':
        print("Secret Seed: "+keypair.secret)
    else:
        pass

    account_url = "https://horizon-testnet.stellar.org/accounts/"+str(keypair.public_key)
    account_info = requests.get(account_url).json()
    balance = account_info['balances'][0]['balance']
    print("This account has {} XLM.".format(balance))
    return keypair

my_key = create_account()

def check_bal(address = None):
    """"checks the balance of a given address or asks the user to input one
    if one is not provided."""
    if address == None:
        address = input("Enter an address to check its current balance: ")
    if type(address) == Keypair:
        address = address.public_key
        
    addr_url = "https://horizon-testnet.stellar.org/accounts/"+address
    response = requests.get(addr_url)
    addr_info = requests.get(addr_url).json()
    
    if response.status_code == 200:
        pass
    else:
        print("Error retrieving balance.")
        return
    balance = addr_info['balances'][0]['balance']
    print("This account has {} XLM.".format(balance))
    

def send_money():
    """"enter the recipient address and amount of XLM to send"""
    recipient_addr = input("Enter the recipient's address: ")
    while len(recipient_addr) != 56 or not recipient_addr.startswith('G'):
        recipient_addr = input("Please enter a valid address. ")
        
    amount = input("Enter the amount of XLM you'd like to send (up to 7 decimal places): ")
    while amount[::-1].find('.') > 7:
        amount = input("You entered too many decimal places. Please try again: ")
    try:
        float(amount)
    except ValueError:
        return "Please type a number. "
    print("You are sending {0} XLM to {1}".format(amount, recipient_addr))
    
    choice = input("Confirm this transaction? Y/N: ")
    if choice.upper() == "Y":
        print("Transaction confirmed.")
        transact(recipient_addr, amount)
    elif choice.upper() == "N":
        print("Transaction cancelled.")
        
def transact(recipient, amount):
    """"this function is called by send_money after inputting the recipient address
    and amount to send"""
    transaction = (
    TransactionBuilder(
        source_account = server.load_account(my_key.public_key),
        network_passphrase = Network.TESTNET_NETWORK_PASSPHRASE,
        base_fee = base_fee,
        )
    .add_text_memo("Here are your Lumens")
    .append_payment_op(recipient, amount)
    .set_timeout(30)
    .build()
    )
    transaction.sign(my_key)
  #  print(transaction.to_xdr())
    response = server.submit_transaction(transaction)
    if response['successful']:
        transaction_info_url = "https://testnet.steexp.com/tx/"+response['hash']
        print("Transaction complete.")
        print("View transaction info on Stellar explorer:", transaction_info_url)
    else:
        print("The transaction failed.")
#    print(response)
